import json
import os
from product import Product
from physical_product import PhysicalProduct
from DigitalProduct import DigitalProduct
from inventory import Inventory
from supplier import Supplier

FILENAME = "inventory.json"


def get_or_create_supplier(data: dict, suppliers: dict[str, Supplier]) -> Supplier:
    """Reuse one Supplier object for every product that shares the same supplier_id."""
    supplier_id = data["supplier_id"]
    if supplier_id not in suppliers:
        suppliers[supplier_id] = Supplier(supplier_id, data["name"], data["contact_email"])
    return suppliers[supplier_id]


def create_product_from_dict(item: dict, suppliers: dict[str, Supplier]) -> Product | None:
    """Build the correct subclass using the saved type."""
    supplier = get_or_create_supplier(item["supplier"], suppliers)
    if item["type"] == "physical":
        return PhysicalProduct(item["id"], item["name"], item["price"], item["stock"], supplier, item["weight"])
    elif item["type"] == "digital":
        return DigitalProduct(item["id"], item["name"], item["price"], item["stock"], supplier, item["download_size"])
    return None


def load_inventory() -> tuple[Inventory, dict[str, Supplier]]:
    inventory = Inventory()
    suppliers: dict[str, Supplier] = {}
    if os.path.exists(FILENAME):
        try:
            with open(FILENAME, "r") as file:
                data = json.load(file)
            print("Inventory loaded successfully.")
            for item in data:
                product = create_product_from_dict(item, suppliers)
                if product is not None:
                    inventory.add_product(product)
        except (json.JSONDecodeError, KeyError):
            print("inventory.json was empty or corrupted. Starting with an empty inventory.")
    else:
        print("inventory.json not found. Starting with an empty inventory.")
    return inventory, suppliers


def save_inventory(inventory):
    with open(FILENAME, "w") as file:
        json.dump(inventory.to_dict_list(), file, indent=4)
    print("Inventory saved successfully.")


def choose_supplier(suppliers: dict[str, Supplier]) -> Supplier | None:
    """Pick an existing supplier by ID, or create a new one independently of any product."""
    supplier_id = input("Supplier ID: ").strip()
    if supplier_id in suppliers:
        return suppliers[supplier_id]
    name = input("New supplier name: ").strip()
    email = input("Supplier contact email: ").strip()
    if not supplier_id or not name:
        print("Supplier ID and name are required.")
        return None
    suppliers[supplier_id] = Supplier(supplier_id, name, email)
    return suppliers[supplier_id]


def add_product_menu(inventory, suppliers):
    print("\nAdd New Product")
    print("1. Physical Product")
    print("2. Digital Product")
    kind = input("Choose type (1/2): ").strip()
    if kind not in ("1", "2"):
        print("Invalid type.")
        return

    prod_id = input("Product ID: ").strip()
    name = input("Product Name: ").strip()
    supplier = choose_supplier(suppliers)
    if supplier is None:
        return

    try:
        price = float(input("Price: "))
        stock = int(input("Stock Quantity: "))
        if kind == "1":
            weight = float(input("Weight (kg): "))
            product = PhysicalProduct(prod_id, name, price, stock, supplier, weight)
        else:
            size = float(input("Download size (MB): "))
            product = DigitalProduct(prod_id, name, price, stock, supplier, size)
    except ValueError:
        print("Error: Invalid number entered.")
        return

    if inventory.add_product(product):
        print("Product added successfully!")
    else:
        print("Error: Product ID already exists!")


def update_stock_menu(inventory):
    print("\nUpdate Stock")
    product_id = input("Enter Product ID to update: ").strip()

    product = inventory.find_product(product_id)
    if product is None:
        print("Product not found.")
        return

    try:
        new_stock = int(input("Enter new stock quantity: "))
    except ValueError:
        print("Error: Stock must be a valid integer.")
        return

    product.update_stock(new_stock)
    print("Stock updated successfully!")


def search_menu(inventory):
    print("\nSearch Product")
    query = input("Enter Product ID or Name to search: ").strip()

    results = inventory.search_product(query)

    if results:
        print("\nSearch Results:")
        for item in results:
            item.display_information()
    else:
        print("No matching product found.")


def main():
    print("=========================================")
    print("INVENTORY MANAGEMENT SYSTEM")
    print("=========================================")

    inventory, suppliers = load_inventory()

    while True:
        print("\n---------- MENU ----------")
        print("1. Display All Products")
        print("2. Add Product")
        print("3. Update Stock")
        print("4. Search Product")
        print("5. Save Inventory")
        print("6. Exit")
        print("--------------------------")

        choice = input("Enter option: ").strip()

        if choice == '1':
            inventory.display_all()
        elif choice == '2':
            add_product_menu(inventory, suppliers)
        elif choice == '3':
            update_stock_menu(inventory)
        elif choice == '4':
            search_menu(inventory)
        elif choice == '5':
            save_inventory(inventory)
        elif choice == '6':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid option. Please enter a number between 1 and 6.")


if __name__ == "__main__":
    main()